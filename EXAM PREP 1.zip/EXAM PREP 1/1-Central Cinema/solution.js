function solve() {
    //select needed elements
    let onScreenBtn = document.querySelector('#container button');
 
    //--add eventlistener to btn 
    onScreenBtn.addEventListener('click', onScreenHandler);
    //*add movie
    function onScreenHandler(e) {
        e.preventDefault()
        let inputs = document.querySelectorAll('#container input');
 
        let movieName = inputs[0];
        let movieHall = inputs[1];
        let ticketPrice = inputs[2];
 
        let name = movieName.value;
        let hall = movieHall.value;
        let price = Number(ticketPrice.value);
        let moviesUl = document.querySelector('#movies ul')
        //--check if all input fields are filled and price is valid
        if (name != '' && hall != '' && price != '' && !isNaN(Number(price))) {
            //--create:
            //---li
            //---span - movie name
            //---strong - `Hall: ${hall}`
            let liElement = document.createElement('li');
            let spanElement = document.createElement('span');
            spanElement.textContent = name;
            let strongElement = document.createElement('strong');
            strongElement.textContent = `Hall: ${hall}`
            //---div
            //-----strong - ${price.toFixed(2)}
            //-----input - placeholder Tickets Sold
            //-----button - Archive
            let divElement = document.createElement('div');
            let priceStrongElement = document.createElement('strong');
            priceStrongElement.textContent = price.toFixed(2);
            let inputElement = document.createElement('input');
            inputElement.setAttribute('placeholder', `Tickets Sold`);
            let archiveBtnElement = document.createElement('button');
            archiveBtnElement.textContent = 'Archive';
            //add event listener to each movie's archive btn
            archiveBtnElement.addEventListener('click', archiveMovieHandler);
 
            //--append all
            divElement.appendChild(priceStrongElement);
            divElement.appendChild(inputElement);
            divElement.appendChild(archiveBtnElement);
 
            liElement.appendChild(spanElement);
            liElement.appendChild(strongElement);
            liElement.appendChild(divElement);
 
            moviesUl.appendChild(liElement);
 
            //--upon click, clear input fields
            movieName.value = '';
            movieHall.value = '';
            ticketPrice.value = '';
        }
 
 
    }
    //*archive functionallity
    function archiveMovieHandler(e) {
        let archivedList = document.querySelector('#archive ul');
        let movieLi = e.target.parentElement.parentElement; //za da hvanem deklariranoto gore 'li'
        let ticketsSoldInput = movieLi.querySelector('div input');
        let ticketsSold = ticketsSoldInput.value;
        //check if input is correct
        if (ticketsSold != '' && !isNaN(Number(ticketsSold))) {
            ticketsSold = Number(ticketsSold);
            let priceStrong = movieLi.querySelector('div strong');
            let price = Number(priceStrong.textContent)
            //modify the previous li:
            let totalPrice = (price * ticketsSold).toFixed(2)
            let hallStrong = movieLi.querySelector('strong');
            hallStrong.textContent = `Total amount: ${totalPrice}`;
 
            let rightDiv = movieLi.querySelector('div');
            rightDiv.remove();
 
            let deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            movieLi.appendChild(deleteBtn);
            //add event listener to all delete btns
            deleteBtn.addEventListener('click', deleteMovie);
            //move element to archive
            archivedList.appendChild(movieLi);
        }
    }
    //delete single movie functionality
    function deleteMovie(e) {
        let elToDelete = e.target.parentElement;
        elToDelete.remove();
    }
 
    let clearBtn = document.querySelector('#archive button');
    //add event listener
    clearBtn.addEventListener('click', clearBtnHandler);
 
    //clear btn functionality
    function clearBtnHandler() {
        //--delete all content in section
        let archiveLis = Array.from(document.querySelectorAll('#archive ul li'));
        archiveLis.forEach(el => el.remove());
    }
}