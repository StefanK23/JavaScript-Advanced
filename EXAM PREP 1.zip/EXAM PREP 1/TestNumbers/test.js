const {expect} = require('chai');
const testNumbers = require('./testNumbers')

describe('Test Numbers', () => {

    describe('sumNumbers',() =>{ 
        it('works with valid numbers',() => {
          expect(testNumbers.sumNumbers(3,5)).to.be.equal('8.00');
        });

        it('works with negative numbers',() => {
            expect(testNumbers.sumNumbers(3, -5)).to.be.equal('-2.00');
        });
        it('works with floating numbers',() => {
            expect(testNumbers.sumNumbers(1.5555, 0.3333)).to.be.equal('1.89');
        });

        it('returns undefined with string params',() => {
            expect(testNumbers.sumNumbers('1', '2')).to.be.equal(undefined);
            expect(testNumbers.sumNumbers('1', 2)).to.be.equal(undefined);
            expect(testNumbers.sumNumbers(1, '2')).to.be.equal(undefined);
        });

        it('returns with one unvalid param',() => {
            expect(testNumbers.sumNumbers(null, 2)).to.be.equal(undefined);
            expect(testNumbers.sumNumbers(2, null)).to.be.equal(undefined);

        });
        

    });

    describe('numberChecker',() =>{ 
        it('works with odd value',() => {
            expect(testNumbers.numberChecker(1)).to.be.contain('odd');
          });

          it('works with even value',() => {
            expect(testNumbers.numberChecker(2)).to.be.contain('even');
          });

          it('works with value as string',() => {
            expect(testNumbers.numberChecker('1')).to.be.contain('odd');
          });

          it('works with value as string',() => {
            expect(testNumbers.numberChecker('2')).to.be.contain('even');
          });

          it('detect ivalid parameter',() => {
            expect(() => testNumbers.numberChecker('a')).to.throw();
          });
          
          
         
    });


    describe('averageSumArray',() =>{ 
               it('works with integers', () => {
                   expect(testNumbers.averageSumArray([1,2,3])).to.be.equal(2);
               });
               it('works with integers', () => {
                expect(testNumbers.averageSumArray([1.5,2.5,3.5])).to.be.equal(2.5);
            });
    });

});