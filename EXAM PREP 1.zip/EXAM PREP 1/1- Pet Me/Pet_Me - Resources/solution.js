function solve() {
    
    const fields = document.querySelectorAll('#container input');
    const addBtn = document.querySelector('#container button');
    
    addBtn.addEventListener("click", onAdd);
    const forAdoptionField = document.querySelector('#adoption ul');
    const adoptedField = document.querySelector('#adopted ul');
    const input = {
        name: fields[0],
        age: fields[1],
        kind: fields[2],
        owner: fields[3]
 
    };
 
    function onAdd(ev) {
        ev.preventDefault();
        const name = input.name.value.trim();
        const age = Number(input.age.value.trim());
        const kind = input.kind.value.trim();
        const owner = input.owner.value.trim();
 
        if(name == '' || input == '' || Number.isNaN(age) || kind == '' || owner=='') {
            return;
        }
        const pet = document.createElement('li');
        pet.innerHTML = `<p><strong>${name}</strong> is a <strong>${age}</strong> year old <strong>${kind}</strong></p>
                        <span>Owner: ${owner}</span>
                        <button>Contact with owner</button>`;
        forAdoptionField.appendChild(pet);
        const contactBtn = pet.querySelector('button');
        contactBtn.addEventListener('click', contact);
        input.name.value = '';
        input.age.value = '';
        input.kind.value = '';
        input.owner.value = '';
 
        function contact() {
            
            const newDiv = document.createElement('div');
            newDiv.innerHTML = `<input placeholder = "Enter your names"><button>Yes! I take it!</button>`;
           
           const inputNewOwner =newDiv.querySelector('input');
            const adoptBtn = newDiv.querySelector('button');
 
            adoptBtn.addEventListener('click',  adopt.bind(null, inputNewOwner, pet));
            contactBtn.remove();
            pet.appendChild(newDiv);
            
        }
        
        
    }
    function adopt(inputNewOwner, pet) {
        const newOwner = inputNewOwner.value.trim();
        if(newOwner =='') {
            return;
        } 
        pet.querySelector('span').textContent = `New Owner: ${newOwner}`;
        const checkBtn = document.createElement('button');
        checkBtn.textContent = 'Checked';
        checkBtn.addEventListener("click", check.bind(null, pet));
        pet.querySelector('div').remove();
        
        pet.appendChild(checkBtn);
        adoptedField.appendChild(pet);
    }
    function check(pet) {
        pet.remove();
    }
  
    
}

